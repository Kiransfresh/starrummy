const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const targets = [
  path.join(root, 'dist'),
  path.join(root, '.vite'),
  path.join(root, 'node_modules', '.vite'),
  path.join(root, 'android', 'app', 'src', 'main', 'assets', 'public'),
];

for (const target of targets) {
  try { fs.rmSync(target, { recursive: true, force: true }); } catch (_) {}
}
fs.mkdirSync(path.join(root, 'android', 'app', 'src', 'main', 'assets', 'public'), { recursive: true });
console.log('Removed stale web/Android assets.');
