import { collection, deleteDoc, doc, getDoc, getDocs, serverTimestamp, setDoc } from 'firebase/firestore'
import { auth, db } from '../firebase'

export const OWNER_ADMIN_EMAIL = 'kvkmsolutions@gmail.com'
export const ADMIN_PERMISSION_KEYS = ['payments', 'gameSettings']

const ALL_PERMISSIONS = Object.freeze({
  payments: true,
  gameSettings: true,
  adminManagement: true,
})

const normalizeEmail = (value = '') => String(value).trim().toLowerCase()

export function isOwnerEmail(email) {
  return normalizeEmail(email) === OWNER_ADMIN_EMAIL
}

export async function getAdminAccessForEmail(email) {
  const normalized = normalizeEmail(email)
  if (!normalized) return null

  if (isOwnerEmail(normalized)) {
    return {
      email: normalized,
      enabled: true,
      isOwner: true,
      permissions: { ...ALL_PERMISSIONS },
    }
  }

  const snap = await getDoc(doc(db, 'adminAccess', normalized))
  if (!snap.exists()) return null
  const data = snap.data() || {}
  if (data.enabled !== true) return null

  return {
    email: normalized,
    enabled: true,
    isOwner: false,
    permissions: {
      payments: data.permissions?.payments === true,
      gameSettings: data.permissions?.gameSettings === true,
      adminManagement: false,
    },
  }
}

export async function getCurrentAdminAccess() {
  const current = auth.currentUser
  if (!current?.email) return null
  return getAdminAccessForEmail(current.email)
}

export async function listDelegatedAdmins() {
  const snap = await getDocs(collection(db, 'adminAccess'))
  return snap.docs
    .map((item) => ({ id: item.id, ...item.data() }))
    .filter((item) => normalizeEmail(item.email || item.id) !== OWNER_ADMIN_EMAIL)
    .sort((a, b) => String(a.email || a.id).localeCompare(String(b.email || b.id)))
}

export async function saveDelegatedAdmin(email, permissions = {}) {
  const normalized = normalizeEmail(email)
  if (!normalized || !normalized.includes('@')) throw new Error('Enter a valid admin email.')
  if (isOwnerEmail(normalized)) throw new Error('The owner account already has full access.')

  await setDoc(doc(db, 'adminAccess', normalized), {
    email: normalized,
    enabled: true,
    permissions: {
      payments: permissions.payments === true,
      gameSettings: permissions.gameSettings === true,
    },
    updatedAt: serverTimestamp(),
    updatedBy: auth.currentUser?.email || OWNER_ADMIN_EMAIL,
  }, { merge: true })
}

export async function revokeDelegatedAdmin(email) {
  const normalized = normalizeEmail(email)
  if (!normalized || isOwnerEmail(normalized)) return
  await deleteDoc(doc(db, 'adminAccess', normalized))
}
