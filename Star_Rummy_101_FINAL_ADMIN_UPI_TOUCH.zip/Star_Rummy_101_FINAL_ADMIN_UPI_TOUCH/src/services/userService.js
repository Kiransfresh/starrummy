import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore'
import { db } from '../firebase'

export async function createUserProfile(uid, phone, extra = {}) {
  const ref = doc(db, 'users', uid)
  const snap = await getDoc(ref)
  if (!snap.exists()) {
    await setDoc(ref, {
      uid,
      phone: phone || '',
      email: extra.email || '',
      name: extra.name || '',
      coins: 5000,
      avatar: 1,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      gamesPlayed: 0,
      gamesWon: 0,
    })
  } else {
    await setDoc(ref, {
      phone: phone || snap.data()?.phone || '',
      email: extra.email || snap.data()?.email || '',
      updatedAt: serverTimestamp(),
    }, { merge: true })
  }
  const updated = await getDoc(ref)
  return updated.data()
}

export async function getUserProfile(uid) {
  const snap = await getDoc(doc(db, 'users', uid))
  return snap.exists() ? snap.data() : null
}

export async function updateUserCoins(uid, newCoins) {
  await setDoc(doc(db, 'users', uid), { coins: newCoins, updatedAt: serverTimestamp() }, { merge: true })
}
