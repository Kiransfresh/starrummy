import {
  collection,
  doc,
  onSnapshot,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  where,
} from 'firebase/firestore'
import { auth, db } from '../firebase'

export const WALLET_CREDIT_RATE = 10 // ₹1 = 10 non-withdrawable game credits
export const UPI_RECEIVER_ID = 'kasturivamsikrishn@ybl'
export const UPI_RECEIVER_NAME = 'Star Rummy'

function cleanUtr(value = '') {
  return String(value).trim().replace(/\s+/g, '').slice(0, 40)
}

export function buildUpiIntent(amountRupees) {
  const amount = Number(amountRupees)
  if (!Number.isFinite(amount) || amount <= 0) throw new Error('Enter a valid amount.')
  const params = new URLSearchParams({
    pa: UPI_RECEIVER_ID,
    pn: UPI_RECEIVER_NAME,
    am: amount.toFixed(2),
    cu: 'INR',
    tn: 'Star Rummy game credits',
  })
  return `upi://pay?${params.toString()}`
}

export async function createWalletTopupRequest({ amountRupees, utr, userName = '', phone = '' }) {
  const current = auth.currentUser
  if (!current?.uid) throw new Error('Please sign in before adding credits.')

  const amount = Math.round(Number(amountRupees))
  const reference = cleanUtr(utr)
  if (!Number.isFinite(amount) || amount < 10 || amount > 50000) {
    throw new Error('Top-up amount must be between ₹10 and ₹50,000.')
  }
  if (reference.length < 6) throw new Error('Enter the UPI transaction/reference number after payment.')

  const credits = amount * WALLET_CREDIT_RATE
  const requestRef = doc(db, 'walletTopups', reference.toUpperCase())
  await setDoc(requestRef, {
    uid: current.uid,
    authEmail: current.email || '',
    phone: phone || current.phoneNumber || '',
    userName: String(userName || '').slice(0, 80),
    amountRupees: amount,
    credits,
    utr: reference.toUpperCase(),
    status: 'pending',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  })
  return requestRef
}

export function subscribeMyTopups(uid, callback, onError) {
  if (!uid) return () => {}
  const q = query(collection(db, 'walletTopups'), where('uid', '==', uid))
  return onSnapshot(q, (snap) => {
    const items = snap.docs.map((item) => ({ id: item.id, ...item.data() }))
    items.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0))
    callback(items)
  }, onError)
}

export function subscribePendingTopups(callback, onError) {
  const q = query(collection(db, 'walletTopups'), where('status', '==', 'pending'))
  return onSnapshot(q, (snap) => {
    const items = snap.docs.map((item) => ({ id: item.id, ...item.data() }))
    items.sort((a, b) => (a.createdAt?.seconds || 0) - (b.createdAt?.seconds || 0))
    callback(items)
  }, onError)
}

export function subscribeUserWallet(uid, callback, onError) {
  if (!uid) return () => {}
  return onSnapshot(doc(db, 'users', uid), (snap) => {
    if (!snap.exists()) return
    const data = snap.data() || {}
    if (Number.isFinite(Number(data.coins))) callback(Number(data.coins))
  }, onError)
}

export async function approveTopup(requestId, adminEmail) {
  if (!requestId) throw new Error('Payment request is missing.')
  return runTransaction(db, async (tx) => {
    const requestRef = doc(db, 'walletTopups', requestId)
    const requestSnap = await tx.get(requestRef)
    if (!requestSnap.exists()) throw new Error('Payment request no longer exists.')

    const request = requestSnap.data() || {}
    if (request.status !== 'pending') throw new Error('This payment was already reviewed.')
    if (!request.uid || !Number.isFinite(Number(request.credits)) || Number(request.credits) <= 0) {
      throw new Error('Invalid wallet request.')
    }

    const userRef = doc(db, 'users', request.uid)
    const userSnap = await tx.get(userRef)
    const currentCoins = userSnap.exists() ? Number(userSnap.data()?.coins || 0) : 0
    const newCoins = currentCoins + Number(request.credits)

    tx.set(userRef, {
      uid: request.uid,
      phone: request.phone || userSnap.data()?.phone || '',
      coins: newCoins,
      updatedAt: serverTimestamp(),
    }, { merge: true })

    tx.update(requestRef, {
      status: 'approved',
      reviewedAt: serverTimestamp(),
      reviewedBy: String(adminEmail || ''),
      updatedAt: serverTimestamp(),
    })

    return { newCoins, credits: Number(request.credits) }
  })
}

export async function rejectTopup(requestId, adminEmail, reason = 'Payment could not be verified') {
  if (!requestId) throw new Error('Payment request is missing.')
  return runTransaction(db, async (tx) => {
    const requestRef = doc(db, 'walletTopups', requestId)
    const requestSnap = await tx.get(requestRef)
    if (!requestSnap.exists()) throw new Error('Payment request no longer exists.')
    const request = requestSnap.data() || {}
    if (request.status !== 'pending') throw new Error('This payment was already reviewed.')

    tx.update(requestRef, {
      status: 'rejected',
      rejectionReason: String(reason || '').slice(0, 200),
      reviewedAt: serverTimestamp(),
      reviewedBy: String(adminEmail || ''),
      updatedAt: serverTimestamp(),
    })
  })
}
