import { io } from 'socket.io-client'

const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || 'https://star-rummy-101-production.up.railway.app'

class SocketService {
  constructor() {
    this.socket = null
    this.isConnected = false
    this.listeners = {}
  }

  connect() {
    if (this.socket) {
      if (!this.socket.connected && !this.socket.active) this.socket.connect()
      return this.socket
    }

    this.socket = io(BACKEND_URL, {
      reconnection: true,
      reconnectionDelay: 700,
      reconnectionDelayMax: 5000,
      reconnectionAttempts: Infinity,
      timeout: 12000,
      transports: ['polling', 'websocket'],
      upgrade: true,
      rememberUpgrade: false,
      forceNew: false,
      autoConnect: true,
    })

    this.socket.on('connect', () => {
      this.isConnected = true
      console.log('[Socket] connected:', this.socket.id)

      Promise.all([
        import('../store'),
        import('./gameSocket'),
      ]).then(([{ default: useGameStore }, { getOrCreatePlayerId }]) => {
        const state = useGameStore?.getState?.()
        const code = state?.activeRoomCode
        if (!code) return
        const playerId = getOrCreatePlayerId?.()
        if (!playerId) return
        this.socket.emit('rejoin_room', { code, playerId }, () => {})
      }).catch(() => {})
    })

    this.socket.on('disconnect', (reason) => {
      this.isConnected = false
      console.log('[Socket] disconnected:', reason)
    })

    this.socket.on('connect_error', (error) => {
      this.isConnected = false
      console.warn('[Socket] connection error:', error?.message || error)
    })

    return this.socket
  }

  getSocket() {
    return this.connect()
  }

  async waitUntilConnected(timeoutMs = 12000) {
    const socket = this.connect()
    if (socket.connected) return socket

    return new Promise((resolve, reject) => {
      let settled = false
      const finish = (fn, value) => {
        if (settled) return
        settled = true
        clearTimeout(timer)
        socket.off('connect', onConnect)
        socket.off('connect_error', onError)
        fn(value)
      }
      const onConnect = () => finish(resolve, socket)
      const onError = (err) => {
        // Keep waiting because Socket.IO can recover on the next transport/retry.
        console.warn('[Socket] waiting for connection:', err?.message || err)
      }
      const timer = setTimeout(() => {
        finish(reject, new Error('Unable to reach the multiplayer server. Check your internet connection and try again.'))
      }, timeoutMs)

      socket.on('connect', onConnect)
      socket.on('connect_error', onError)
      if (!socket.connected) socket.connect()
    })
  }

  async emitWithAck(eventName, payload = {}, timeoutMs = 10000) {
    const socket = await this.waitUntilConnected(timeoutMs)
    return new Promise((resolve, reject) => {
      socket.timeout(timeoutMs).emit(eventName, payload, (err, response) => {
        if (err) {
          reject(new Error('The server did not respond. Please try again.'))
          return
        }
        resolve(response || { ok: true })
      })
    })
  }

  async emitWithResponseEvent(eventName, payload, successEvent, {
    timeoutMs = 10000,
    matcher = () => true,
    errorEvent = 'room_error',
  } = {}) {
    const socket = await this.waitUntilConnected(timeoutMs)

    return new Promise((resolve, reject) => {
      let settled = false
      const finish = (fn, value) => {
        if (settled) return
        settled = true
        clearTimeout(timer)
        socket.off(successEvent, onSuccess)
        if (errorEvent) socket.off(errorEvent, onError)
        fn(value)
      }
      const onSuccess = (data = {}) => {
        if (!matcher(data)) return
        finish(resolve, { ok: true, ...data })
      }
      const onError = (data = {}) => {
        finish(resolve, { ok: false, ...data, message: data?.message || 'Request failed.' })
      }
      const timer = setTimeout(() => {
        finish(reject, new Error('The multiplayer server did not respond. Please try again.'))
      }, timeoutMs)

      socket.on(successEvent, onSuccess)
      if (errorEvent) socket.on(errorEvent, onError)
      socket.emit(eventName, payload, (response) => {
        if (!response || settled) return
        finish(resolve, response)
      })
    })
  }

  async registerRoom({ code, playerName, playerId, entryFee = 0 }) {
    return this.emitWithResponseEvent(
      'register_room',
      { code, playerName, playerId, entryFee },
      'room_registered',
      { matcher: data => data?.code === code },
    )
  }

  async joinPrivateRoom({ code, playerName, playerId }) {
    return this.emitWithResponseEvent(
      'join_room',
      { code, playerName, playerId },
      'room_update',
      {
        matcher: data => data?.code === code && (data.players || []).some(p => p.playerId === playerId),
      },
    )
  }

  async validatePrivateRoom(code) {
    return this.emitWithResponseEvent(
      'validate_room',
      { code },
      'room_validated',
      { matcher: data => data?.code === code, errorEvent: null },
    )
  }

  async rejoinPrivateRoom({ code, playerId }) {
    return this.emitWithResponseEvent(
      'rejoin_room',
      { code, playerId },
      'room_rejoined',
      { matcher: data => data?.code === code, errorEvent: null },
    )
  }

  async startPrivateGame({ code, playerId }) {
    return this.emitWithResponseEvent(
      'start_game',
      { code, playerId },
      'game_starting',
      { matcher: data => data?.code === code, errorEvent: 'game_error' },
    )
  }

  disconnect() {
    if (this.socket) {
      this.socket.disconnect()
      this.isConnected = false
    }
  }

  // Compatibility helpers retained for older screens/components.
  joinRoom(roomCode, userId, entryFee = 0) {
    this.socket?.emit('join_room', { code: roomCode, playerId: userId, entryFee })
  }
  drawCard(roomCode, fromDiscard = false) {
    this.socket?.emit('draw_card', { code: roomCode, fromDiscard })
  }
  discardCard(roomCode, cardId) {
    this.socket?.emit('discard_card', { code: roomCode, cardId })
  }
  groupCards(roomCode, groups) {
    this.socket?.emit('group_cards', { code: roomCode, groups })
  }
  declare(roomCode) {
    this.socket?.emit('declare', { code: roomCode })
  }
  dropGame(roomCode, penalty = 20) {
    this.socket?.emit('drop_game', { code: roomCode, penalty })
  }
  startGame(roomCode) {
    this.socket?.emit('start_game', { code: roomCode })
  }

  onRoomUpdate(callback) { this._listen('room_update', callback) }
  onGameStarting(callback) { this._listen('game_starting', callback) }
  onGameState(callback) { this._listen('game_state', callback) }
  onMoveError(callback) { this._listen('move_error', callback) }
  onPlayerDisconnected(callback) { this._listen('player_disconnected', callback) }
  onPlayerDeclared(callback) { this._listen('player_declared', callback) }
  onPlayerDropped(callback) { this._listen('player_dropped', callback) }
  onPlayerLeft(callback) { this._listen('player_left', callback) }
  onRoomError(callback) { this._listen('room_error', callback) }
  onReconnected(callback) { this._listen('room_rejoined', callback) }

  _listen(eventName, callback) {
    this.socket?.on(eventName, callback)
    this.listeners[eventName] = callback
  }

  removeAllListeners() {
    Object.keys(this.listeners).forEach((eventName) => {
      this.socket?.off(eventName, this.listeners[eventName])
    })
    this.listeners = {}
  }

  removeListener(eventName) {
    if (this.listeners[eventName]) {
      this.socket?.off(eventName, this.listeners[eventName])
      delete this.listeners[eventName]
    }
  }
}

const socketService = new SocketService()
export default socketService

export function testJoinRoom() {
  const s = socketService.getSocket()
  import('../store').then(({ default: useGameStore }) => {
    const state = useGameStore.getState()
    const code = state.activeRoomCode
    if (!code) return
    const playerName = state.user?.name || state.profileName || 'TestPlayer'
    import('./gameSocket').then(({ getOrCreatePlayerId }) => {
      s.emit('join_room', { code, playerName, playerId: getOrCreatePlayerId() })
    })
  })
}
