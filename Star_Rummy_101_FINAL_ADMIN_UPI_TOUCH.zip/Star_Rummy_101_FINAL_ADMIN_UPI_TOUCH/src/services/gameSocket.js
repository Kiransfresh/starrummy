import socketService from './socket'

function getOrCreatePlayerId() {
  try {
    let id = localStorage.getItem('star_rummy_player_id')
    if (!id) {
      id = `pid_${Math.random().toString(36).slice(2)}_${Date.now()}`
      localStorage.setItem('star_rummy_player_id', id)
    }
    return id
  } catch {
    if (!globalThis.__starRummyFallbackPlayerId) {
      globalThis.__starRummyFallbackPlayerId = `pid_${Math.random().toString(36).slice(2)}_${Date.now()}`
    }
    return globalThis.__starRummyFallbackPlayerId
  }
}

export { getOrCreatePlayerId }

export function emitStartGame(code) {
  const s = socketService.getSocket()
  if (!s?.connected) return false
  const playerId = getOrCreatePlayerId()
  s.emit('start_game', { code, playerId })
  return true
}

export function emitDrawCard(code, fromDiscard = false) {
  const s = socketService.getSocket()
  if (!s?.connected) return false
  const playerId = getOrCreatePlayerId()
  s.emit('draw_card', { code, playerId, fromDiscard })
  return true
}

export function emitDiscardCard(code, cardId) {
  const s = socketService.getSocket()
  if (!s?.connected) return false
  const playerId = getOrCreatePlayerId()
  s.emit('discard_card', { code, cardId, playerId })
  return true
}

export function subscribeToGame(code, myPlayerId, callbacks = {}) {
  const s = socketService.getSocket()
  if (!s) return () => {}

  const {
    onGameState = () => {},
    onGameError = () => {},
    onHostChanged = () => {},
    onRoomClosed = () => {},
  } = callbacks

  function handleGameState(data) {
    if (data?.code !== code) return
    onGameState(data)
  }

  function handleGameError(data) {
    onGameError(data || { message: 'Game error' })
  }

  function handleHostChanged(data) {
    if (data?.code && data.code !== code) return
    onHostChanged(data)
  }

  function handleRoomClosed(data) {
    if (data?.code && data.code !== code) return
    onRoomClosed(data)
  }

  s.on('game_state', handleGameState)
  s.on('game_error', handleGameError)
  s.on('host_changed', handleHostChanged)
  s.on('room_closed', handleRoomClosed)

  return () => {
    s.off('game_state', handleGameState)
    s.off('game_error', handleGameError)
    s.off('host_changed', handleHostChanged)
    s.off('room_closed', handleRoomClosed)
  }
}
