import React, { useState } from 'react'
import { signInWithEmailAndPassword, signOut } from 'firebase/auth'
import { auth } from '../firebase'
import useGameStore from '../store'
import { getAdminAccessForEmail, OWNER_ADMIN_EMAIL } from '../services/adminAccess'

export default function AdminLogin() {
  const setScreen = useGameStore((s) => s.setScreen)
  const setUser = useGameStore((s) => s.setUser)
  const [email, setEmail] = useState(OWNER_ADMIN_EMAIL)
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function submit(e) {
    e.preventDefault()
    setError('')
    try {
      setBusy(true)
      const result = await signInWithEmailAndPassword(auth, email.trim().toLowerCase(), password)
      const access = await getAdminAccessForEmail(result.user.email)
      if (!access) {
        await signOut(auth)
        throw new Error('This email does not have Star Rummy admin access.')
      }
      const token = await result.user.getIdToken()
      localStorage.setItem('firebase_id_token', token)
      localStorage.removeItem('isGuest')
      localStorage.removeItem('guestUser')
      setUser({
        uid: result.user.uid,
        email: result.user.email,
        name: access.isOwner ? 'Owner Admin' : 'Admin',
        jwt: token,
        coins: 0,
        isAdmin: true,
      })
      setScreen('admin')
    } catch (e2) {
      console.error(e2)
      setError(e2.code === 'auth/invalid-credential' ? 'Invalid admin email or password.' : (e2.message || 'Admin sign-in failed.'))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div style={{ width: '100%', height: '100%', background: '#07100b', color: '#fff', overflowY: 'auto', fontFamily: "'Nunito',sans-serif" }}>
      <div style={{ padding: '52px 16px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid rgba(255,255,255,.08)' }}>
        <button onClick={() => setScreen('otp')} style={{ width: 38, height: 38, borderRadius: '50%', border: '1px solid rgba(255,255,255,.15)', background: 'rgba(255,255,255,.04)', color: '#fff', fontSize: 20 }}>‹</button>
        <b style={{ color: '#F5C518', letterSpacing: 1.5 }}>ADMIN SIGN IN</b>
        <div style={{ width: 38 }} />
      </div>
      <form onSubmit={submit} style={{ margin: '36px 16px', padding: 20, borderRadius: 20, background: '#10251a', border: '1px solid rgba(245,197,24,.18)' }}>
        <div style={{ fontSize: 30, textAlign: 'center', marginBottom: 8 }}>🛡️</div>
        <div style={{ textAlign: 'center', color: '#9bb1a3', fontSize: 12, marginBottom: 22, lineHeight: 1.5 }}>
          Owner access is reserved for <b style={{ color: '#fff' }}>{OWNER_ADMIN_EMAIL}</b>. Delegated admins must be added by the owner first.
        </div>
        <label style={label}>EMAIL</label>
        <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" autoComplete="username" style={input} />
        <label style={label}>PASSWORD</label>
        <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" autoComplete="current-password" style={input} />
        {error && <div style={{ color: '#ff7777', fontSize: 12, fontWeight: 800, marginTop: 10 }}>{error}</div>}
        <button disabled={busy || !email || !password} style={{ width: '100%', marginTop: 16, padding: 12, borderRadius: 12, border: 0, background: '#F5C518', color: '#162016', fontWeight: 1000, opacity: busy ? .6 : 1 }}>
          {busy ? 'SIGNING IN…' : 'SIGN IN TO ADMIN'}
        </button>
      </form>
    </div>
  )
}

const label = { display: 'block', color: '#91aa9b', fontSize: 10, fontWeight: 900, margin: '10px 0 5px', letterSpacing: .6 }
const input = { width: '100%', boxSizing: 'border-box', padding: 12, borderRadius: 11, border: '1px solid rgba(255,255,255,.14)', background: 'rgba(0,0,0,.24)', color: '#fff', outline: 'none' }
