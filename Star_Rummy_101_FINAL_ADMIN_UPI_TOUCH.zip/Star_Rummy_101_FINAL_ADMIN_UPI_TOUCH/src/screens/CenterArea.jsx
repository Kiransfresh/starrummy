import React from 'react'
import { getCardImage } from '../utils/cardImage'
import { motion } from 'framer-motion'
import cardBackImg from '../assets/Star_Rummy_card.png'
import { useDroppable } from '@dnd-kit/core'

function CardBack({ style = {} }) {
  return (
    <img
      src={cardBackImg}
      alt="Card Back"
      draggable={false}
      style={{
        width: '100%', height: '100%', objectFit: 'fill', display: 'block',
        borderRadius: 7,
        border: '1px solid rgba(255,255,255,0.15)',
        boxShadow: '0 5px 14px rgba(0,0,0,0.46)',
        userSelect: 'none', WebkitUserSelect: 'none', pointerEvents: 'none',
        ...style,
      }}
    />
  )
}

function CardFace({ card, style = {} }) {
  if (!card) return null
  const isJokerCard = card.isWildJoker || card.isJoker
  return (
    <div style={{
      width: '100%', height: '100%', borderRadius: 7, background: '#fff', overflow: 'hidden',
      border: isJokerCard ? '2px solid #f6c945' : '1px solid rgba(8,16,12,0.22)',
      boxShadow: '0 5px 14px rgba(0,0,0,0.42)',
      userSelect: 'none', WebkitUserSelect: 'none', pointerEvents: 'none', ...style,
    }}>
      <img
        src={getCardImage(card.rank, card.suit)}
        alt={`${card.rank}${card.suit}`}
        draggable={false}
        style={{ width: '100%', height: '100%', objectFit: 'fill', display: 'block', borderRadius: 5 }}
      />
    </div>
  )
}

function tapHandler(enabled, callback) {
  if (!enabled) return undefined
  return (event) => {
    event.preventDefault()
    event.stopPropagation()
    callback?.()
  }
}

export default function CenterArea({
  wildJoker,
  drawPile,
  discardPile,
  gameState,
  isPlayerTurn,
  onDrawClosed,
  onDrawOpen,
  onDeclare,
  canDrawClosed = false,
  canDrawOpen = false,
  canDeclare = false,
  drawPileRef,
  discardPileRef,
  cardW = 72,
  cardH = 100,
}) {
  const topCard = discardPile[discardPile.length - 1]
  const closedEnabled = canDrawClosed && isPlayerTurn && drawPile.length > 0
  const openEnabled = canDrawOpen && isPlayerTurn && !!topCard
  const cW = cardW
  const cH = cardH
  const { setNodeRef } = useDroppable({ id: 'discard-pile' })
  const touchPad = 15

  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      gap: Math.max(12, Math.round(cW * 0.26)),
      zIndex: 4, position: 'relative', pointerEvents: 'auto',
      opacity: gameState === 'dealing' ? 0 : 1,
      transition: 'opacity 0.22s ease',
    }}>
      <div ref={drawPileRef} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <div style={{ position: 'relative', width: cW, height: cH }}>
          <div style={{ position: 'absolute', top: -4, left: -4, width: cW, height: cH, opacity: 0.35 }}><CardBack /></div>
          <div style={{ position: 'absolute', top: -2, left: -2, width: cW, height: cH, opacity: 0.65 }}><CardBack /></div>

          {wildJoker && (
            <div style={{
              position: 'absolute', top: '50%', left: -(cW * 0.43),
              width: cW - 6, height: cH - 6,
              transform: 'translateY(-50%) rotate(-90deg)',
              zIndex: 2, pointerEvents: 'none',
            }}>
              <CardFace card={wildJoker} />
            </div>
          )}

          <motion.button
            type="button"
            aria-label="Draw from closed deck"
            whileTap={closedEnabled ? { scale: 0.96 } : {}}
            onPointerUp={tapHandler(closedEnabled, onDrawClosed)}
            disabled={!closedEnabled}
            style={{
              position: 'absolute', top: -touchPad, left: -touchPad,
              width: cW + touchPad * 2, height: cH + touchPad * 2,
              padding: touchPad, border: 0, background: 'transparent',
              pointerEvents: 'auto', zIndex: 3,
              cursor: closedEnabled ? 'pointer' : 'not-allowed',
              touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent',
              opacity: closedEnabled ? 1 : 0.7,
            }}
          >
            <div style={{ width: cW, height: cH }}><CardBack /></div>
          </motion.button>
        </div>
      </div>

      <motion.button
        type="button"
        aria-label="Finish and declare"
        disabled={!canDeclare}
        onPointerUp={tapHandler(canDeclare, onDeclare)}
        whileTap={canDeclare ? { scale: 0.96 } : {}}
        style={{
          width: cW, height: cH, borderRadius: 7,
          background: 'rgba(0,0,0,0.24)',
          border: '2px dashed rgba(255,255,255,0.32)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: canDeclare ? 'pointer' : 'default',
          boxShadow: 'inset 0 2px 8px rgba(0,0,0,0.34)',
          flexDirection: 'column', gap: 3, touchAction: 'manipulation',
          padding: 0, color: 'inherit',
        }}
      >
        <div style={{
          width: cW * 0.48, height: cH * 0.43, borderRadius: 4,
          border: '1.5px solid rgba(255,255,255,0.17)',
          background: 'rgba(255,255,255,0.035)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 2,
        }}><span style={{ fontSize: 14, opacity: 0.48 }}>🃏</span></div>
        <span style={{
          color: canDeclare ? '#f6c945' : 'rgba(255,255,255,0.48)',
          fontSize: 8, fontWeight: 900, letterSpacing: 0.5, textTransform: 'uppercase',
        }}>Finish</span>
      </motion.button>

      <div
        ref={(node) => {
          if (discardPileRef) {
            if (typeof discardPileRef === 'function') discardPileRef(node)
            else discardPileRef.current = node
          }
          setNodeRef(node)
        }}
        style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}
      >
        <motion.button
          type="button"
          aria-label="Draw from open deck"
          disabled={!openEnabled}
          onPointerUp={tapHandler(openEnabled, onDrawOpen)}
          whileTap={openEnabled ? { scale: 0.96 } : {}}
          style={{
            width: cW + touchPad * 2, height: cH + touchPad * 2,
            padding: touchPad, border: 0, background: 'transparent',
            cursor: openEnabled ? 'pointer' : 'default', touchAction: 'manipulation',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            WebkitTapHighlightColor: 'transparent',
          }}
        >
          <div style={{ width: cW, height: cH, opacity: openEnabled ? 1 : 0.7 }}>
            {topCard ? <CardFace card={topCard} /> : (
              <div style={{
                width: '100%', height: '100%', borderRadius: 7,
                background: 'rgba(0,0,0,0.25)', border: '1.5px dashed rgba(255,255,255,0.22)',
              }} />
            )}
          </div>
        </motion.button>
      </div>
    </div>
  )
}
