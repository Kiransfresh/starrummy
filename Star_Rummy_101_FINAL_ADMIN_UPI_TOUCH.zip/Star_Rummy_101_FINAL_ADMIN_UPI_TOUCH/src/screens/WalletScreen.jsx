import React, { useEffect, useMemo, useState } from 'react'
import useGameStore from '../store'
import {
  buildUpiIntent,
  createWalletTopupRequest,
  subscribeMyTopups,
  UPI_RECEIVER_ID,
  WALLET_CREDIT_RATE,
} from '../services/walletService'

const C = {
  bg: '#07150e',
  card: '#0f281b',
  card2: '#123522',
  gold: '#F5C518',
  green: '#30d17c',
  red: '#ff6b6b',
  blue: '#60a5fa',
  muted: '#91aa9b',
  white: '#fff',
}

const PRESETS = [100, 500, 1000, 2000]

function fmtDate(value) {
  try {
    const d = value?.toDate?.() || (value ? new Date(value) : null)
    return d && !Number.isNaN(d.getTime()) ? d.toLocaleString() : 'Just now'
  } catch (_) {
    return 'Just now'
  }
}

export default function WalletScreen() {
  const setScreen = useGameStore((s) => s.setScreen)
  const user = useGameStore((s) => s.user)
  const coins = useGameStore((s) => s.coins)
  const profileName = useGameStore((s) => s.profileName)

  const [amount, setAmount] = useState(() => {
    const prefill = Number(localStorage.getItem('wallet_prefill_amount'))
    localStorage.removeItem('wallet_prefill_amount')
    return Number.isFinite(prefill) && prefill >= 10 ? prefill : 500
  })
  const [utr, setUtr] = useState('')
  const [paid, setPaid] = useState(false)
  const [requests, setRequests] = useState([])
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  const credits = useMemo(() => Math.max(0, Number(amount) || 0) * WALLET_CREDIT_RATE, [amount])

  useEffect(() => {
    if (!user?.uid || user?.isGuest) return undefined
    return subscribeMyTopups(user.uid, setRequests, (e) => {
      console.warn('[Wallet] history listener:', e)
    })
  }, [user?.uid, user?.isGuest])

  function startUpiPayment() {
    setError('')
    setMessage('')
    try {
      const url = buildUpiIntent(amount)
      setPaid(true)
      window.location.href = url
    } catch (e) {
      setError(e.message || 'Unable to open UPI app.')
    }
  }

  async function copyUpi() {
    try {
      await navigator.clipboard.writeText(UPI_RECEIVER_ID)
      setMessage('UPI ID copied.')
    } catch (_) {
      setMessage(`UPI ID: ${UPI_RECEIVER_ID}`)
    }
  }

  async function submitForApproval() {
    setError('')
    setMessage('')
    if (user?.isGuest) {
      setError('Please sign in with OTP before adding wallet credits.')
      return
    }
    try {
      setBusy(true)
      await createWalletTopupRequest({
        amountRupees: amount,
        utr,
        userName: profileName || user?.name || user?.displayName || 'Player',
        phone: user?.phone || user?.phoneNumber || '',
      })
      setUtr('')
      setPaid(false)
      setMessage('Payment reference sent to admin. Credits will update automatically after approval.')
    } catch (e) {
      console.error(e)
      setError(e.message || 'Unable to submit payment for approval.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div style={{
      width: '100%', height: '100%', overflowY: 'auto',
      background: `radial-gradient(circle at 50% -10%, rgba(245,197,24,.15), transparent 34%), ${C.bg}`,
      color: C.white, fontFamily: "'Nunito', sans-serif",
    }}>
      <div style={{
        position: 'sticky', top: 0, zIndex: 10,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '48px 16px 14px', background: 'rgba(7,21,14,.94)',
        borderBottom: '1px solid rgba(255,255,255,.08)', backdropFilter: 'blur(14px)',
      }}>
        <button onClick={() => setScreen('home')} style={iconButton}>‹</button>
        <div style={{ fontWeight: 950, letterSpacing: 1.5, color: C.gold }}>WALLET</div>
        <div style={{ width: 38 }} />
      </div>

      <div style={{ padding: '18px 16px 42px' }}>
        <div style={{
          borderRadius: 22, padding: 20, marginBottom: 16,
          background: 'linear-gradient(135deg, #173e28, #0c2418)',
          border: '1px solid rgba(245,197,24,.28)',
          boxShadow: '0 16px 44px rgba(0,0,0,.28)',
        }}>
          <div style={{ color: C.muted, fontSize: 11, fontWeight: 800, letterSpacing: 1.1 }}>AVAILABLE GAME CREDITS</div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 9, marginTop: 6 }}>
            <div style={{ fontSize: 34, fontWeight: 1000, color: C.gold }}>{Number(coins || 0).toLocaleString()}</div>
            <div style={{ color: C.muted, fontWeight: 800 }}>credits</div>
          </div>
          <div style={{ marginTop: 10, fontSize: 11, color: C.muted, lineHeight: 1.5 }}>
            Credits are in-app game credits only. They are not cash, cannot be withdrawn, and do not guarantee any prize or return.
          </div>
        </div>

        <section style={sectionStyle}>
          <div style={sectionTitle}>ADD CREDITS</div>
          <div style={{ color: C.muted, fontSize: 12, marginBottom: 12 }}>₹1 = {WALLET_CREDIT_RATE} game credits</div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 7, marginBottom: 12 }}>
            {PRESETS.map((v) => (
              <button key={v} onClick={() => setAmount(v)} style={{
                padding: '10px 4px', borderRadius: 11,
                border: `1px solid ${Number(amount) === v ? C.gold : 'rgba(255,255,255,.1)'}`,
                background: Number(amount) === v ? 'rgba(245,197,24,.12)' : 'rgba(255,255,255,.035)',
                color: Number(amount) === v ? C.gold : C.white, fontWeight: 900,
              }}>₹{v}</button>
            ))}
          </div>

          <label style={labelStyle}>CUSTOM AMOUNT</label>
          <input
            value={amount}
            inputMode="numeric"
            onChange={(e) => setAmount(e.target.value.replace(/\D/g, '').slice(0, 5))}
            style={inputStyle}
            placeholder="Amount in ₹"
          />

          <div style={{
            margin: '12px 0', padding: '11px 13px', borderRadius: 12,
            background: 'rgba(48,209,124,.08)', border: '1px solid rgba(48,209,124,.2)',
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          }}>
            <span style={{ color: C.muted, fontSize: 12 }}>You will receive</span>
            <b style={{ color: C.green }}>{credits.toLocaleString()} credits</b>
          </div>

          <div style={{
            borderRadius: 13, background: 'rgba(0,0,0,.22)', padding: 12,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10,
          }}>
            <div>
              <div style={{ fontSize: 10, color: C.muted, fontWeight: 800 }}>PAY TO UPI</div>
              <div style={{ fontWeight: 900, fontSize: 13, marginTop: 2, wordBreak: 'break-all' }}>{UPI_RECEIVER_ID}</div>
            </div>
            <button onClick={copyUpi} style={smallBtn}>COPY</button>
          </div>

          <button onClick={startUpiPayment} disabled={!Number(amount) || Number(amount) < 10} style={{
            ...primaryBtn, width: '100%', marginTop: 12,
            opacity: !Number(amount) || Number(amount) < 10 ? .45 : 1,
          }}>PAY ₹{Number(amount || 0).toLocaleString()} VIA UPI</button>

          <div style={{ height: 1, background: 'rgba(255,255,255,.08)', margin: '18px 0' }} />

          <div style={{ fontWeight: 900, fontSize: 13, marginBottom: 5 }}>After payment</div>
          <div style={{ color: C.muted, fontSize: 11, lineHeight: 1.5, marginBottom: 10 }}>
            Return to Star Rummy, enter the UPI transaction/reference number, and send it for admin verification.
          </div>
          <label style={labelStyle}>UPI TRANSACTION / UTR</label>
          <input
            value={utr}
            onChange={(e) => setUtr(e.target.value.replace(/[^a-zA-Z0-9]/g, '').slice(0, 40))}
            style={inputStyle}
            placeholder="Example: 426812345678"
          />
          <button onClick={submitForApproval} disabled={busy || utr.length < 6} style={{
            ...secondaryBtn, width: '100%', marginTop: 10,
            opacity: busy || utr.length < 6 ? .45 : 1,
          }}>{busy ? 'SENDING…' : 'SEND FOR ADMIN APPROVAL'}</button>

          {paid && <div style={{ color: C.blue, fontSize: 11, marginTop: 10 }}>UPI was opened. Submit your reference number only after completing payment.</div>}
          {message && <div style={{ color: C.green, fontSize: 12, fontWeight: 800, marginTop: 10 }}>{message}</div>}
          {error && <div style={{ color: C.red, fontSize: 12, fontWeight: 800, marginTop: 10 }}>{error}</div>}
        </section>

        <section style={sectionStyle}>
          <div style={sectionTitle}>PAYMENT STATUS</div>
          {requests.length === 0 ? (
            <div style={{ color: C.muted, fontSize: 12, padding: '12px 0' }}>No top-up requests yet.</div>
          ) : requests.slice(0, 10).map((item) => {
            const statusColor = item.status === 'approved' ? C.green : item.status === 'rejected' ? C.red : C.gold
            return (
              <div key={item.id} style={{
                padding: '12px 0', borderBottom: '1px solid rgba(255,255,255,.07)',
                display: 'grid', gridTemplateColumns: '1fr auto', gap: 8,
              }}>
                <div>
                  <div style={{ fontWeight: 900 }}>₹{Number(item.amountRupees || 0).toLocaleString()} · {Number(item.credits || 0).toLocaleString()} credits</div>
                  <div style={{ color: C.muted, fontSize: 10, marginTop: 3 }}>UTR {item.utr} · {fmtDate(item.createdAt)}</div>
                  {item.rejectionReason && <div style={{ color: C.red, fontSize: 10, marginTop: 3 }}>{item.rejectionReason}</div>}
                </div>
                <div style={{
                  alignSelf: 'start', padding: '4px 8px', borderRadius: 999,
                  border: `1px solid ${statusColor}55`, color: statusColor,
                  fontSize: 9, fontWeight: 1000, textTransform: 'uppercase',
                }}>{item.status || 'pending'}</div>
              </div>
            )
          })}
        </section>
      </div>
    </div>
  )
}

const iconButton = {
  width: 38, height: 38, borderRadius: '50%', border: '1px solid rgba(255,255,255,.14)',
  background: 'rgba(0,0,0,.28)', color: '#fff', fontSize: 22, display: 'grid', placeItems: 'center',
}
const sectionStyle = {
  background: C.card, borderRadius: 18, border: '1px solid rgba(255,255,255,.08)',
  padding: 16, marginBottom: 14, boxShadow: '0 12px 35px rgba(0,0,0,.18)',
}
const sectionTitle = { color: C.gold, fontWeight: 1000, fontSize: 12, letterSpacing: 1, marginBottom: 12 }
const labelStyle = { display: 'block', color: C.muted, fontSize: 10, fontWeight: 900, letterSpacing: .6, margin: '8px 0 5px' }
const inputStyle = {
  width: '100%', boxSizing: 'border-box', padding: '12px 13px', borderRadius: 12,
  border: '1px solid rgba(255,255,255,.13)', background: 'rgba(0,0,0,.24)', color: '#fff',
  outline: 'none', fontSize: 14, fontWeight: 800,
}
const primaryBtn = {
  padding: '12px 14px', borderRadius: 12, border: 0,
  background: 'linear-gradient(180deg,#ffd84a,#e9ae08)', color: '#132016',
  fontWeight: 1000, letterSpacing: .3,
}
const secondaryBtn = {
  padding: '12px 14px', borderRadius: 12,
  border: '1px solid rgba(48,209,124,.45)', background: 'rgba(48,209,124,.11)',
  color: C.green, fontWeight: 1000,
}
const smallBtn = {
  padding: '7px 9px', borderRadius: 9, border: '1px solid rgba(245,197,24,.35)',
  background: 'rgba(245,197,24,.1)', color: C.gold, fontSize: 10, fontWeight: 1000,
}
