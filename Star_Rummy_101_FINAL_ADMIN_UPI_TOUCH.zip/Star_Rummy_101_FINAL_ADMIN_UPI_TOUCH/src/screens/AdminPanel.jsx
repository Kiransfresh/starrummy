import React, { useEffect, useMemo, useState } from 'react'
import useGameStore from '../store'
import useAdminStore from '../store/adminStore'
import {
  getCurrentAdminAccess,
  listDelegatedAdmins,
  OWNER_ADMIN_EMAIL,
  revokeDelegatedAdmin,
  saveDelegatedAdmin,
} from '../services/adminAccess'
import { approveTopup, rejectTopup, subscribePendingTopups } from '../services/walletService'

const C = {
  bg: '#07110b', panel: '#10251a', panel2: '#142e20', gold: '#F5C518',
  green: '#30d17c', blue: '#60a5fa', red: '#ff6b6b', muted: '#93aa9c', white: '#fff',
}

function Slider({ label, value, min, max, step = 1, unit = '', onChange }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 7 }}>
        <b style={{ fontSize: 10, color: C.muted, letterSpacing: .7 }}>{label}</b>
        <b style={{ color: C.gold, fontSize: 12 }}>{value}{unit}</b>
      </div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} style={{ width: '100%', accentColor: C.gold }} />
    </div>
  )
}

function fmtDate(value) {
  try {
    const d = value?.toDate?.() || (value ? new Date(value) : null)
    return d && !Number.isNaN(d.getTime()) ? d.toLocaleString() : 'Just now'
  } catch (_) { return 'Just now' }
}

export default function AdminPanel() {
  const setScreen = useGameStore((s) => s.setScreen)
  const [access, setAccess] = useState(null)
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState('payments')
  const [pending, setPending] = useState([])
  const [delegates, setDelegates] = useState([])
  const [actionId, setActionId] = useState('')
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [newEmail, setNewEmail] = useState('')
  const [newPermissions, setNewPermissions] = useState({ payments: true, gameSettings: false })

  const {
    botCount, botWinRate, botSpeed, turnTimer, penaltyTimer, botDifficulty, botNames,
    updateConfig, resetConfig,
  } = useAdminStore()

  useEffect(() => {
    let active = true
    getCurrentAdminAccess()
      .then((value) => {
        if (!active) return
        setAccess(value)
        setLoading(false)
        if (value?.permissions?.payments) setTab('payments')
        else if (value?.permissions?.gameSettings) setTab('game')
        else if (value?.isOwner) setTab('admins')
      })
      .catch((e) => { console.error(e); if (active) { setError('Unable to verify admin access.'); setLoading(false) } })
    return () => { active = false }
  }, [])

  useEffect(() => {
    if (!access?.permissions?.payments) return undefined
    return subscribePendingTopups((items) => setPending(items), (e) => {
      console.error(e)
      setError('Unable to load pending payment requests. Check Firestore rules.')
    })
  }, [access?.permissions?.payments])

  async function refreshDelegates() {
    if (!access?.isOwner) return
    try { setDelegates(await listDelegatedAdmins()) } catch (e) { setError(e.message || 'Unable to load admins.') }
  }

  useEffect(() => { refreshDelegates() }, [access?.isOwner])

  const tabs = useMemo(() => {
    const out = []
    if (access?.permissions?.payments) out.push(['payments', `Payments${pending.length ? ` (${pending.length})` : ''}`])
    if (access?.permissions?.gameSettings) out.push(['game', 'Game Settings'])
    if (access?.isOwner) out.push(['admins', 'Admin Access'])
    return out
  }, [access, pending.length])

  async function review(item, decision) {
    setActionId(item.id)
    setError('')
    setNotice('')
    try {
      if (decision === 'approve') {
        const result = await approveTopup(item.id, access.email)
        setNotice(`Approved ${result.credits.toLocaleString()} credits. User wallet updated to ${result.newCoins.toLocaleString()}.`)
      } else {
        await rejectTopup(item.id, access.email)
        setNotice('Payment request rejected. No credits were added.')
      }
    } catch (e) {
      setError(e.message || 'Unable to review payment.')
    } finally {
      setActionId('')
    }
  }

  async function addDelegate() {
    setError(''); setNotice('')
    try {
      await saveDelegatedAdmin(newEmail, newPermissions)
      setNotice(`Admin access saved for ${newEmail.trim().toLowerCase()}.`)
      setNewEmail('')
      setNewPermissions({ payments: true, gameSettings: false })
      await refreshDelegates()
    } catch (e) { setError(e.message || 'Unable to add admin.') }
  }

  async function removeDelegate(email) {
    if (!window.confirm(`Remove admin access for ${email}?`)) return
    setError(''); setNotice('')
    try {
      await revokeDelegatedAdmin(email)
      setNotice(`Removed admin access for ${email}.`)
      await refreshDelegates()
    } catch (e) { setError(e.message || 'Unable to remove admin.') }
  }

  if (loading) return <Centered text="Verifying admin access…" />
  if (!access) {
    return (
      <Centered text="Admin access denied">
        <button onClick={() => setScreen('admin-login')} style={primaryBtn}>ADMIN SIGN IN</button>
        <button onClick={() => setScreen('home')} style={ghostBtn}>BACK TO APP</button>
      </Centered>
    )
  }

  return (
    <div style={{ width: '100%', height: '100%', overflow: 'hidden', background: C.bg, color: C.white, fontFamily: "'Nunito',sans-serif", display: 'flex', flexDirection: 'column' }}>
      <header style={{ padding: '48px 14px 12px', display: 'flex', alignItems: 'center', gap: 10, borderBottom: '1px solid rgba(255,255,255,.08)', background: 'rgba(7,17,11,.96)' }}>
        <button onClick={() => setScreen('home')} style={roundBtn}>‹</button>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 1000, color: C.gold, letterSpacing: 1.2 }}>STAR RUMMY ADMIN</div>
          <div style={{ fontSize: 9, color: C.muted, marginTop: 2 }}>{access.email}{access.isOwner ? ' · OWNER' : ' · DELEGATED ADMIN'}</div>
        </div>
        <div style={{ width: 9, height: 9, borderRadius: '50%', background: C.green, boxShadow: `0 0 14px ${C.green}` }} />
      </header>

      <nav style={{ display: 'flex', gap: 7, padding: '10px 12px', overflowX: 'auto', borderBottom: '1px solid rgba(255,255,255,.06)' }}>
        {tabs.map(([key, label]) => (
          <button key={key} onClick={() => setTab(key)} style={{
            padding: '8px 10px', borderRadius: 999, whiteSpace: 'nowrap',
            border: `1px solid ${tab === key ? C.gold : 'rgba(255,255,255,.1)'}`,
            background: tab === key ? 'rgba(245,197,24,.12)' : 'rgba(255,255,255,.025)',
            color: tab === key ? C.gold : C.muted, fontSize: 10, fontWeight: 1000,
          }}>{label}</button>
        ))}
      </nav>

      <main style={{ flex: 1, overflowY: 'auto', padding: '14px 12px 40px' }}>
        {notice && <div style={{ ...alertBox, color: C.green, borderColor: 'rgba(48,209,124,.25)', background: 'rgba(48,209,124,.07)' }}>{notice}</div>}
        {error && <div style={{ ...alertBox, color: C.red, borderColor: 'rgba(255,107,107,.25)', background: 'rgba(255,107,107,.07)' }}>{error}</div>}

        {tab === 'payments' && access.permissions.payments && (
          <>
            <Section title="PENDING UPI TOP-UPS" subtitle="Verify the UTR/reference in your UPI/bank app before approval. Approval uses a Firestore transaction so a request cannot be credited twice.">
              {pending.length === 0 ? (
                <Empty text="No payments waiting for approval." />
              ) : pending.map((item) => (
                <div key={item.id} style={{ padding: 13, borderRadius: 14, background: C.panel2, border: '1px solid rgba(255,255,255,.07)', marginBottom: 10 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10 }}>
                    <div>
                      <div style={{ fontWeight: 1000, fontSize: 16 }}>₹{Number(item.amountRupees || 0).toLocaleString()}</div>
                      <div style={{ color: C.green, fontSize: 11, fontWeight: 900 }}>{Number(item.credits || 0).toLocaleString()} game credits</div>
                    </div>
                    <div style={{ color: C.gold, fontSize: 9, fontWeight: 1000, border: '1px solid rgba(245,197,24,.28)', borderRadius: 999, padding: '4px 8px', height: 'fit-content' }}>PENDING</div>
                  </div>
                  <div style={metaRow}><span>User</span><b>{item.userName || item.phone || item.uid}</b></div>
                  <div style={metaRow}><span>Phone</span><b>{item.phone || '—'}</b></div>
                  <div style={metaRow}><span>UTR</span><b style={{ color: C.gold, letterSpacing: .4 }}>{item.utr}</b></div>
                  <div style={metaRow}><span>Submitted</span><b>{fmtDate(item.createdAt)}</b></div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 12 }}>
                    <button disabled={actionId === item.id} onClick={() => review(item, 'reject')} style={{ ...dangerBtn, opacity: actionId === item.id ? .5 : 1 }}>REJECT</button>
                    <button disabled={actionId === item.id} onClick={() => review(item, 'approve')} style={{ ...successBtn, opacity: actionId === item.id ? .5 : 1 }}>{actionId === item.id ? 'PROCESSING…' : 'APPROVE + CREDIT'}</button>
                  </div>
                </div>
              ))}
            </Section>
          </>
        )}

        {tab === 'game' && access.permissions.gameSettings && (
          <Section title="PRACTICE / TABLE SETTINGS" subtitle="These controls apply to local practice AI and timers. Multiplayer card state remains server-authoritative.">
            <Slider label="PRACTICE BOTS" value={botCount} min={1} max={5} unit=" bots" onChange={(v) => updateConfig('botCount', v)} />
            <Slider label="PRACTICE AI TARGET WIN RATE" value={botWinRate} min={0} max={100} step={5} unit="%" onChange={(v) => updateConfig('botWinRate', v)} />
            <Slider label="BOT TURN DELAY" value={botSpeed} min={300} max={3000} step={100} unit="ms" onChange={(v) => updateConfig('botSpeed', v)} />
            <Slider label="TURN TIMER" value={turnTimer} min={10} max={60} unit="s" onChange={(v) => updateConfig('turnTimer', v)} />
            <Slider label="PENALTY TIMER" value={penaltyTimer} min={5} max={30} unit="s" onChange={(v) => updateConfig('penaltyTimer', v)} />
            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 10, color: C.muted, fontWeight: 900, marginBottom: 7 }}>BOT DIFFICULTY</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 7 }}>
                {['easy', 'medium', 'hard'].map((v) => <button key={v} onClick={() => updateConfig('botDifficulty', v)} style={{ ...choiceBtn, borderColor: botDifficulty === v ? C.gold : 'rgba(255,255,255,.1)', color: botDifficulty === v ? C.gold : C.muted }}>{v.toUpperCase()}</button>)}
              </div>
            </div>
            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 10, color: C.muted, fontWeight: 900, marginBottom: 7 }}>BOT NAMES</div>
              <div style={{ color: C.white, fontSize: 12, lineHeight: 1.7 }}>{botNames.join(' · ')}</div>
            </div>
            <button onClick={resetConfig} style={ghostBtn}>RESET PRACTICE SETTINGS</button>
          </Section>
        )}

        {tab === 'admins' && access.isOwner && (
          <>
            <Section title="OWNER ACCOUNT" subtitle="Only the owner can create, change, or revoke delegated admin access.">
              <div style={{ color: C.gold, fontWeight: 1000 }}>{OWNER_ADMIN_EMAIL}</div>
              <div style={{ color: C.muted, fontSize: 10, marginTop: 4 }}>Full permissions · cannot be removed in-app</div>
            </Section>
            <Section title="ADD / UPDATE ADMIN" subtitle="The email must also have a Firebase Email/Password account before it can sign in.">
              <input type="email" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} placeholder="admin@example.com" style={input} />
              <PermissionToggle label="Approve wallet top-ups" checked={newPermissions.payments} onChange={(v) => setNewPermissions((p) => ({ ...p, payments: v }))} />
              <PermissionToggle label="Change game/practice settings" checked={newPermissions.gameSettings} onChange={(v) => setNewPermissions((p) => ({ ...p, gameSettings: v }))} />
              <button onClick={addDelegate} disabled={!newEmail.includes('@')} style={{ ...primaryBtn, width: '100%', opacity: !newEmail.includes('@') ? .45 : 1 }}>SAVE ADMIN ACCESS</button>
            </Section>
            <Section title="DELEGATED ADMINS">
              {delegates.length === 0 ? <Empty text="No delegated admins." /> : delegates.map((item) => (
                <div key={item.id} style={{ padding: 12, borderRadius: 12, background: C.panel2, marginBottom: 8, border: '1px solid rgba(255,255,255,.07)' }}>
                  <div style={{ fontWeight: 900, fontSize: 12, wordBreak: 'break-all' }}>{item.email || item.id}</div>
                  <div style={{ color: C.muted, fontSize: 10, margin: '5px 0 10px' }}>
                    {item.permissions?.payments ? 'Payments' : ''}{item.permissions?.payments && item.permissions?.gameSettings ? ' · ' : ''}{item.permissions?.gameSettings ? 'Game Settings' : ''}
                  </div>
                  <button onClick={() => removeDelegate(item.email || item.id)} style={dangerBtn}>REVOKE ACCESS</button>
                </div>
              ))}
            </Section>
          </>
        )}
      </main>
    </div>
  )
}

function Centered({ text, children }) {
  return <div style={{ width: '100%', height: '100%', background: C.bg, color: C.white, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12, fontFamily: "'Nunito',sans-serif" }}><b>{text}</b>{children}</div>
}
function Section({ title, subtitle, children }) {
  return <section style={{ background: C.panel, borderRadius: 18, border: '1px solid rgba(255,255,255,.08)', padding: 15, marginBottom: 13, boxShadow: '0 12px 36px rgba(0,0,0,.18)' }}><div style={{ color: C.gold, fontWeight: 1000, fontSize: 11, letterSpacing: .8 }}>{title}</div>{subtitle && <div style={{ color: C.muted, fontSize: 10, lineHeight: 1.5, margin: '5px 0 14px' }}>{subtitle}</div>}{!subtitle && <div style={{ height: 10 }} />}{children}</section>
}
function Empty({ text }) { return <div style={{ color: C.muted, fontSize: 11, padding: '12px 0' }}>{text}</div> }
function PermissionToggle({ label, checked, onChange }) {
  return <label style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0', color: C.white, fontSize: 11, fontWeight: 800 }}><input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} style={{ width: 18, height: 18, accentColor: C.gold }} />{label}</label>
}

const roundBtn = { width: 38, height: 38, borderRadius: '50%', border: '1px solid rgba(255,255,255,.14)', background: 'rgba(255,255,255,.04)', color: C.white, fontSize: 22 }
const primaryBtn = { padding: '11px 14px', borderRadius: 11, border: 0, background: C.gold, color: '#172016', fontWeight: 1000, fontSize: 10 }
const successBtn = { padding: '10px 8px', borderRadius: 10, border: '1px solid rgba(48,209,124,.35)', background: 'rgba(48,209,124,.12)', color: C.green, fontWeight: 1000, fontSize: 9 }
const dangerBtn = { padding: '10px 8px', borderRadius: 10, border: '1px solid rgba(255,107,107,.3)', background: 'rgba(255,107,107,.09)', color: C.red, fontWeight: 1000, fontSize: 9 }
const ghostBtn = { padding: '10px 12px', borderRadius: 10, border: '1px solid rgba(255,255,255,.13)', background: 'rgba(255,255,255,.03)', color: C.muted, fontWeight: 900, fontSize: 9 }
const choiceBtn = { padding: '9px 5px', borderRadius: 9, border: '1px solid rgba(255,255,255,.1)', background: 'rgba(255,255,255,.03)', fontSize: 9, fontWeight: 1000 }
const input = { width: '100%', boxSizing: 'border-box', padding: 11, borderRadius: 11, border: '1px solid rgba(255,255,255,.13)', background: 'rgba(0,0,0,.22)', color: C.white, outline: 'none', marginBottom: 8 }
const metaRow = { display: 'flex', justifyContent: 'space-between', gap: 8, color: C.muted, fontSize: 10, paddingTop: 7 }
const alertBox = { padding: 10, borderRadius: 10, border: '1px solid', marginBottom: 10, fontSize: 10, fontWeight: 800, lineHeight: 1.4 }
