import React, { useEffect, useMemo, useRef, useState } from 'react'
import { getCardImage } from '../utils/cardImage'
import { motion } from 'framer-motion'
import {
  DndContext,
  PointerSensor,
  useDroppable,
  useSensor,
  useSensors,
  closestCenter,
} from '@dnd-kit/core'
import {
  SortableContext,
  useSortable,
  horizontalListSortingStrategy,
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'

const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
function asArray(v) { return Array.isArray(v) ? v : [] }
function clamp(min, v, max) { return Math.min(Math.max(v, min), max) }

function CardFace({ card, selected = false, style = {} }) {
  if (!card) return null
  const isJokerCard = card.isWildJoker || card.isJoker
  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        borderRadius: 7,
        background: '#fff',
        border: isJokerCard
          ? '2px solid #f6c945'
          : selected
            ? '2px solid rgba(255,214,74,0.95)'
            : '1px solid rgba(8,16,12,0.22)',
        boxShadow: selected
          ? '0 0 0 2px rgba(255,214,74,0.25), 0 10px 24px rgba(0,0,0,0.5)'
          : '0 5px 14px rgba(0,0,0,0.38)',
        userSelect: 'none',
        overflow: 'hidden',
        flexShrink: 0,
        position: 'relative',
        pointerEvents: 'none',
        ...style,
      }}
    >
      <img
        src={getCardImage(card.rank, card.suit)}
        alt={`${card.rank}${card.suit}`}
        style={{ width: '100%', height: '100%', objectFit: 'fill', display: 'block', borderRadius: 5 }}
        draggable={false}
      />
      <div style={{
        position: 'absolute', inset: 0, borderRadius: 5,
        boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.35)',
        pointerEvents: 'none',
      }} />
    </div>
  )
}

function evalGroup(group) {
  const g = asArray(group).filter(Boolean)
  if (!g.length) return { label: 'Empty', pts: 0, valid: false }
  const jokers = g.filter(c => c.isJoker || c.isWildJoker)
  const nat = g.filter(c => !c.isJoker && !c.isWildJoker)
  const pts = nat.reduce((s, c) => s + (c.pts || 0), 0)

  if (!jokers.length && nat.length >= 3) {
    const sameSuit = nat.every(c => c.suit === nat[0].suit)
    if (sameSuit) {
      const idx = nat.map(c => RANKS.indexOf(c.rank)).sort((a, b) => a - b)
      if (idx.every((v, i) => i === 0 || v === idx[i - 1] + 1)) {
        return { label: 'Pure Seq', pts: 0, valid: true, type: 'pureSeq' }
      }
    }
  }

  if (nat.length >= 2) {
    const sameSuit = nat.every(c => c.suit === nat[0].suit)
    if (sameSuit) {
      const idx = nat.map(c => RANKS.indexOf(c.rank)).sort((a, b) => a - b)
      const gaps = idx.reduce((a, v, i) => i === 0 ? 0 : a + (v - idx[i - 1] - 1), 0)
      if (gaps <= jokers.length && nat.length + jokers.length >= 3) {
        return { label: 'Sequence', pts: 0, valid: true, type: 'seq' }
      }
    }

    const sameRank = nat.every(c => c.rank === nat[0].rank)
    const uniqueSuits = new Set(nat.map(c => c.suit)).size
    const total = nat.length + jokers.length
    if (sameRank && uniqueSuits === nat.length && total >= 3 && total <= 4) {
      return { label: 'Set', pts: 0, valid: true, type: 'set' }
    }
  }

  return { label: `${pts}pts`, pts, valid: false, type: 'invalid' }
}

function SortableCard({ card, selected, cardW, cardH, onClick, idx, cardStep }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: card.id })
  const pointerStartRef = useRef(null)
  if (card?.id == null) return null
  const transformString = CSS.Transform.toString({
    ...transform,
    scaleX: transform?.scaleX ?? 1,
    scaleY: transform?.scaleY ?? 1,
  })

  function handlePointerDown(e) {
    pointerStartRef.current = { x: e.clientX, y: e.clientY, pointerId: e.pointerId }
    listeners?.onPointerDown?.(e)
  }

  function handlePointerCancel() {
    pointerStartRef.current = null
  }

  function handlePointerUp(e) {
    const start = pointerStartRef.current
    pointerStartRef.current = null
    if (!start || isDragging) return
    const dx = Math.abs(e.clientX - start.x)
    const dy = Math.abs(e.clientY - start.y)
    if (dx <= 10 && dy <= 10) onClick?.()
  }

  return (
    <div
      ref={setNodeRef}
      data-card-id={card.id}
      {...attributes}
      {...Object.fromEntries(Object.entries(listeners ?? {}).filter(([key]) => key !== 'onPointerDown'))}
      onPointerDown={handlePointerDown}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerCancel}
      style={{
        width: cardW,
        height: cardH,
        flex: `0 0 ${cardW}px`,
        position: 'relative',
        marginLeft: idx === 0 ? 0 : -(cardW - cardStep),
        zIndex: isDragging ? 9999 : selected ? 200 : idx + 1,
        opacity: isDragging ? 0.92 : 1,
        transform: transformString || undefined,
        transition,
        touchAction: 'none',
        userSelect: 'none',
        WebkitUserSelect: 'none',
        WebkitTapHighlightColor: 'transparent',
        cursor: isDragging ? 'grabbing' : 'grab',
        boxSizing: 'border-box',
        contain: 'layout style',
      }}
    >
      <motion.div
        animate={
          isDragging ? { y: -10, scale: 1.045 }
            : selected ? { y: -13, scale: 1.025 }
              : { y: 0, scale: 1 }
        }
        transition={{ duration: 0.18, ease: [0.22, 1, 0.36, 1] }}
        style={{ width: cardW, height: cardH, borderRadius: 7, transformOrigin: 'bottom center' }}
      >
        <CardFace card={card} selected={selected} />
      </motion.div>
    </div>
  )
}

function GroupDropZone({ group, groupIndex, cardW, cardH, cardStep, selectedCardId, selectedCardIds = [], onCardSelect }) {
  const safe = asArray(group).filter(Boolean)
  const { setNodeRef, isOver } = useDroppable({ id: `group-${groupIndex}`, data: { groupIndex } })
  const ev = evalGroup(safe)
  const groupVisualWidth = safe.length > 0 ? cardW + (safe.length - 1) * cardStep : cardW

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, flexShrink: 0 }}>
      <motion.div
        ref={setNodeRef}
        animate={{ scale: isOver ? 1.018 : 1, y: isOver ? -3 : 0 }}
        transition={{ duration: 0.14 }}
        style={{
          display: 'flex',
          alignItems: 'flex-end',
          padding: '20px 2px 3px',
          borderRadius: 9,
          background: isOver ? 'rgba(255,255,255,0.035)' : 'transparent',
          minHeight: cardH + 25,
          minWidth: groupVisualWidth + 4,
          overflow: 'visible',
        }}
      >
        {safe.length === 0 ? (
          <div style={{
            width: cardW,
            height: cardH,
            borderRadius: 7,
            border: '1.5px dashed rgba(255,255,255,0.25)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'rgba(255,255,255,0.38)',
            fontSize: 13,
          }}>+</div>
        ) : safe.map((card, i) => (
          <SortableCard
            key={card.id}
            card={card}
            idx={i}
            cardW={cardW}
            cardH={cardH}
            cardStep={cardStep}
            selected={selectedCardId === card.id || selectedCardIds.includes(card.id)}
            onClick={() => onCardSelect(card)}
          />
        ))}
      </motion.div>

      {safe.length > 0 && (
        <div style={{
          padding: '2px 7px',
          borderRadius: 999,
          background: ev.valid ? 'rgba(34,197,94,0.16)' : 'rgba(239,83,80,0.13)',
          border: `1px solid ${ev.valid ? 'rgba(34,197,94,0.45)' : 'rgba(239,83,80,0.38)'}`,
          minWidth: 44,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <span style={{
            color: ev.valid ? '#55df78' : '#ff746f',
            fontSize: 8,
            fontWeight: 900,
            whiteSpace: 'nowrap',
            letterSpacing: 0.1,
          }}>{ev.label}</span>
        </div>
      )}
    </div>
  )
}

export default function PlayerHand({
  playerHand,
  selectedCard,
  selectedCards = [],
  cardW,
  cardH,
  handRef,
  sortRef,
  onCardSelect,
  canInteract = true,
  canDiscard = false,
  onDiscard = null,
  viewportWidth = 1200,
}) {
  const [handGroups, setHandGroups] = useState(() => {
    const cards = asArray(playerHand).filter(Boolean)
    return cards.length > 0 ? [cards] : [[]]
  })
  const [activeId, setActiveId] = useState(null)
  const [handWidth, setHandWidth] = useState(0)
  const prevFlatIdsRef = useRef('')

  useEffect(() => {
    if (sortRef) sortRef.current = setHandGroups
  }, [sortRef])

  useEffect(() => {
    const newCards = asArray(playerHand).filter(Boolean)
    const newIdSet = new Set(newCards.map(c => c.id))
    const newIds = [...newIdSet].sort().join(',')
    if (newIds === prevFlatIdsRef.current) return
    prevFlatIdsRef.current = newIds
    const newCardMap = new Map(newCards.map(c => [c.id, c]))

    setHandGroups(prev => {
      const existingIds = new Set(prev.flat().filter(Boolean).map(c => c.id))
      const sameCards = newCards.length === existingIds.size && newCards.every(c => existingIds.has(c.id))
      if (sameCards && prev.flat().length === newCards.length) {
        return prev.map(g => g.map(c => newCardMap.get(c.id)).filter(Boolean)).filter(g => g.length > 0)
      }

      const updated = prev
        .map(g => g.filter(c => newCardMap.has(c.id)).map(c => newCardMap.get(c.id)))
        .filter(g => g.length > 0)
      const updatedIds = new Set(updated.flat().map(c => c.id))
      const added = newCards.filter(c => !updatedIds.has(c.id))

      if (added.length > 0) {
        if (updated.length === 0) return [added]
        return [...updated.slice(0, -1), [...updated[updated.length - 1], ...added]]
      }
      return updated.length > 0 ? updated : [[]]
    })
  }, [playerHand])

  const safeGroups = useMemo(() => {
    const groups = asArray(handGroups)
    return groups.length > 0 ? groups.map(asArray) : [[]]
  }, [handGroups])
  const flatHand = useMemo(() => safeGroups.flat().filter(Boolean), [safeGroups])
  const sortableIds = useMemo(() => flatHand.filter(c => c?.id != null).map(c => c.id), [flatHand])

  // One pointer sensor handles mouse, stylus and modern Android/iOS touch.
  // Using both PointerSensor and TouchSensor can double-activate on WebViews.
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 7 } }),
  )

  const fW = cardW
  const fH = cardH

  useEffect(() => {
    if (!handRef?.current) return
    const node = handRef.current
    const update = () => setHandWidth(node.getBoundingClientRect().width || 0)
    update()
    const ro = new ResizeObserver(update)
    ro.observe(node)
    window.addEventListener('resize', update)
    return () => {
      ro.disconnect()
      window.removeEventListener('resize', update)
    }
  }, [handRef])

  const groupGap = useMemo(
    () => clamp(5, Math.round((handWidth || viewportWidth) * 0.009), 12),
    [handWidth, viewportWidth],
  )

  const cardStep = useMemo(() => {
    const totalCards = Math.max(flatHand.length, 1)
    const groupCount = Math.max(safeGroups.length, 1)
    const transitions = Math.max(totalCards - groupCount, 1)
    const available = Math.max((handWidth || viewportWidth) - 18, 250)
    const fixed = groupCount * fW + Math.max(groupCount - 1, 0) * groupGap
    const solved = (available - fixed) / transitions
    return clamp(Math.max(24, fW * 0.38), solved, fW * 0.86)
  }, [flatHand.length, safeGroups.length, fW, groupGap, handWidth, viewportWidth])

  function handleDragStart({ active }) {
    if (!canInteract) return
    onCardSelect?.(null)
    setActiveId(active.id)
  }

  function handleDragCancel() {
    setActiveId(null)
  }

  function handleDragEnd({ active, over, delta }) {
    setActiveId(null)
    if (!canInteract) return

    const draggedCard = flatHand.find(c => c.id === active.id)
    if (!draggedCard) return

    const draggedFarUp = (delta?.y || 0) < -140
    const draggedFarAway = Math.abs(delta?.x || 0) > 220 || Math.abs(delta?.y || 0) > 170
    if ((draggedFarUp || draggedFarAway) && canDiscard && onDiscard) {
      onDiscard(draggedCard)
      return
    }

    if (!over) return
    if (over.id === 'discard-pile') {
      if (canDiscard && onDiscard) onDiscard(draggedCard)
      return
    }

    const sourceGroup = safeGroups.findIndex(group => group.some(card => card.id === active.id))
    if (sourceGroup === -1) return
    const sourceIndex = safeGroups[sourceGroup].findIndex(card => card.id === active.id)
    const nextGroups = safeGroups.map(group => [...group])
    const [movedCard] = nextGroups[sourceGroup].splice(sourceIndex, 1)

    if (over.data?.current?.groupIndex !== undefined) {
      nextGroups[over.data.current.groupIndex].push(movedCard)
    } else {
      const targetGroup = safeGroups.findIndex(group => group.some(card => card.id === over.id))
      if (targetGroup !== -1) {
        const targetIndex = nextGroups[targetGroup].findIndex(card => card.id === over.id)
        nextGroups[targetGroup].splice(targetIndex, 0, movedCard)
      } else {
        nextGroups[sourceGroup].splice(Math.min(sourceIndex, nextGroups[sourceGroup].length), 0, movedCard)
      }
    }

    setHandGroups(nextGroups.filter(group => group.length))
  }

  const handContent = (
    <div
      ref={handRef}
      style={{
        width: 'calc(100vw - 16px)',
        maxWidth: 1120,
        display: 'flex',
        alignItems: 'flex-end',
        gap: groupGap,
        padding: '22px 8px 0',
        boxSizing: 'border-box',
        justifyContent: 'center',
        overflow: 'visible',
        position: 'relative',
        touchAction: 'none',
      }}
    >
      {safeGroups.map((group, gi) => (
        <GroupDropZone
          key={`g-${gi}`}
          group={group}
          groupIndex={gi}
          cardW={fW}
          cardH={fH}
          cardStep={cardStep}
          selectedCardId={selectedCard?.id}
          selectedCardIds={selectedCards.map(c => c.id)}
          onCardSelect={card => canInteract && onCardSelect?.(card)}
        />
      ))}
    </div>
  )

  return (
    <div style={{
      width: '100%',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      paddingBottom: 2,
      paddingTop: 2,
      overflow: 'visible',
      position: 'relative',
      zIndex: activeId ? 9999 : 'auto',
    }}>
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={handleDragStart}
        onDragCancel={handleDragCancel}
        onDragEnd={handleDragEnd}
      >
        {canInteract && sortableIds.length > 0 ? (
          <SortableContext items={sortableIds} strategy={horizontalListSortingStrategy}>
            {handContent}
          </SortableContext>
        ) : handContent}
      </DndContext>
    </div>
  )
}
